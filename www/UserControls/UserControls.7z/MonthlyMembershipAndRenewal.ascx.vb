﻿Imports Umbraco
Imports Umbraco.NodeFactory
Imports Common


Public Class MonthlyMembershipAndRenewal
    Inherits System.Web.Mvc.ViewUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'txbFirstName.Value = Hidden1.Value
    End Sub




    'Private Sub Button1_ServerClick(sender As Object, e As EventArgs) Handles Button1.ServerClick
    '    txbFirstName.Value = Hidden1.Value
    'End Sub
    'Private Sub Reset1_ServerClick(sender As Object, e As EventArgs) Handles Reset1.ServerClick
    '    txbFirstName.Value = Hidden1.Value
    'End Sub
    'Private Sub Submit1_ServerClick(sender As Object, e As EventArgs) Handles Submit1.ServerClick
    '    txbFirstName.Value = Hidden1.Value
    'End Sub
End Class