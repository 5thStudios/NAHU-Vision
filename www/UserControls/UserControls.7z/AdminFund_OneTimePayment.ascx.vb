﻿
Partial Class UserControls_AdminFund_OneTimePayment
    Inherits System.Web.Mvc.ViewTemplateUserControl

End Class
