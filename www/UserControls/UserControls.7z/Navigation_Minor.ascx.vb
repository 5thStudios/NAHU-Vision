﻿Imports Examine
Imports Common
Imports UmbracoExamine
Imports Umbraco
Imports Umbraco.NodeFactory


Public Class Navigation_Minor
    Inherits System.Web.Mvc.ViewUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            ''Instantiate variables
            'Dim homeNodeId As Integer = getHomeNodeId(Node.getCurrentNodeId)

            ''Hide link according to current site.
            'Select Case homeNodeId
            '    Case siteNodes.Home
            '        liNahu.Visible = False
            '    Case siteNodes.EducationFoundation
            '        liEducationFoundation.Visible = False
            '    Case siteNodes.HUPAC
            '        liHupac.Visible = False
            'End Select

            'USE EXAMINE.EXAMINEMANAGER TO SEARCH   https://our.umbraco.org/documentation/reference/searching/examine/overview-explanation#querying-with-examine
            '===============================================
            'Instantiate search provider and criteria
            Dim searchProvider As Providers.BaseSearchProvider = Examine.ExamineManager.Instance.SearchProviderCollection(searchIndex.NavigationSearcher)
            Dim searchCriteria As SearchCriteria.ISearchCriteria = searchProvider.CreateSearchCriteria()

            'Obtain all marked items sorted by name
            Dim query = searchCriteria.Field(nodeProperties.showInEyebrowNavigation, CInt(True)).[And]().OrderBy(nodeProperties.nodeName)
            Dim searchResults = searchProvider.Search(query.Compile())

            'Loop thru each id and build link
            For Each result As Examine.SearchResult In searchResults
                'Instantiate variables
                Dim thisNode As New Node(result.Id)
                Dim lstIDs As List(Of Integer)

                'Obtain path list
                lstIDs = thisNode.Path.Split(",").ToList.ConvertAll(Function(str) Int32.Parse(str))

                'Add to list only if the node's level does not exceed the max level and is part of the main site.
                If (lstIDs(1) = getHomeNodeId(Node.getCurrentNodeId)) Then
                    'Instantiate variables
                    Dim href As New HyperLink
                    Dim pnl As New Panel
                    'build link and add to list
                    pnl.Controls.Add(New LiteralControl(thisNode.Name))
                    If thisNode.NodeTypeAlias = aliases.externalLink Then
                        href.NavigateUrl = thisNode.GetProperty(Of String)(nodeProperties.externalUrl)
                    Else
                        href.NavigateUrl = thisNode.NiceUrl
                    End If
                    href.Controls.Add(pnl)
                    pnlMinorNavLinks.Controls.Add(href)
                End If
            Next

            'Add link to search page with parameter.
            'hfldSearchPg.Value = New Node(siteNodes.Search).NiceUrl
            Select Case getHomeNodeId(Node.getCurrentNodeId)
                Case siteNodes.Home
                    hfldSearchPg.Value = New Node(siteNodes.Search).NiceUrl
                Case siteNodes.EducationFoundation
                    hfldSearchPg.Value = New Node(siteNodes.Search_EF).NiceUrl
                Case siteNodes.HUPAC
                    hfldSearchPg.Value = New Node(siteNodes.Search_Hupac).NiceUrl
            End Select

        Catch ex As Exception
            'Save error to umbraco
            Dim sb As New StringBuilder
            sb.AppendLine("Navigation_Minor.vb | Load()")
            saveErrorMessage(ex.ToString, sb.ToString)
        End Try
    End Sub

End Class