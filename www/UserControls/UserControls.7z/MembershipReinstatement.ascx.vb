﻿Imports Umbraco
Imports Umbraco.NodeFactory
Imports Common


Public Class MembershipReinstatement
    Inherits System.Web.Mvc.ViewUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class