﻿Imports System.Xml.XPath
Imports System.Collections.Generic
Imports Common
Imports Examine
Imports Umbraco
Imports UmbracoExamine
Imports Umbraco.NodeFactory
Imports System.Net
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.Data
Imports System.Xml

Public Class SearchList
    Inherits System.Web.Mvc.ViewUserControl



#Region "Properties"
#End Region

#Region "Handles"
    Private Sub SearchList_Load(sender As Object, e As EventArgs) Handles Me.Load
        '
        'ONLY USE THIS FOR TESTING.  ACTUAL CODE IS LOCATED IN SERVICES/SITESEARCH.ASHX
        '

        'Try
        '    Dim tempSearchFor As String = "law"
        '    'Search for data in videos
        '    Dim lstSearch_videoList As List(Of DataLayer.SearchList) = SearchVideosFor(tempSearchFor)
        '    'gv.DataSource = lstSearch_videoList
        '    'gv.DataBind()



        '    Dim lstSearch_articleList As List(Of DataLayer.SearchList) = SearchExamineFor(tempSearchFor)
        '    'gv2.DataSource = lstSearch_articleList
        '    'gv2.DataBind()


        '    Dim lstSearchResults As New List(Of DataLayer.SearchList)

        '    lstSearchResults.AddRange(SearchVideosFor(tempSearchFor))
        '    lstSearchResults.AddRange(SearchExamineFor(tempSearchFor))
        '    'sort list
        '    gv3.DataSource = lstSearchResults.OrderBy(Function(x) x.title)
        '    gv3.DataBind()



        'Catch ex As Exception
        '    lblErrorMsg.Text = "Error: " & ex.ToString
        'End Try
    End Sub

#End Region

#Region "Methods"
    Private Function SearchExamineFor(ByVal searchFor As String) As List(Of DataLayer.SearchList)
        'Instantiate scope variable
        Dim lstSearchList As New List(Of DataLayer.SearchList)

        Try
            'Instantiate variables
            Dim searchEntry As DataLayer.SearchList

            'Instantiate search provider and criteria
            Dim searchProvider As Providers.BaseSearchProvider = Examine.ExamineManager.Instance.SearchProviderCollection(searchIndex.ExternalSearcher)
            Dim searchCriteria As SearchCriteria.ISearchCriteria = searchProvider.CreateSearchCriteria()

            'Obtain all marked items
            Dim query = searchCriteria.RawQuery(searchFor)
            Dim searchResults = searchProvider.Search(query)

            'Loop thru each id and build link list
            For Each result As Examine.SearchResult In searchResults
                'Create node
                Dim thisNode As New Node(result.Id)
                'Skip if there is no id
                If thisNode.Id = 0 Then Continue For
                'Add data to class
                searchEntry = New DataLayer.SearchList
                searchEntry.id = thisNode.Id
                searchEntry.title = thisNode.Name
                searchEntry.url = thisNode.NiceUrl
                Select Case thisNode.NodeTypeAlias
                    Case aliases.lockedBlogEntry, aliases.lockedPdfEntry
                        searchEntry.isLocked = True
                End Select
                'Split path to create a breadcrumb
                Dim first As Boolean = True
                For Each _id As String In thisNode.Path.Split(",").ToList
                    Dim id As Integer = CInt(_id)
                    If id <> -1 Then
                        If first Then
                            first = False
                        Else
                            searchEntry.breadcrumb += "&nbsp;&nbsp;⇢&nbsp;&nbsp;"
                        End If
                        searchEntry.breadcrumb += New Node(id).Name
                    End If
                Next

                'Add to list
                lstSearchList.Add(searchEntry)
            Next

        Catch ex As Exception
            Response.Write("Error retrieving data from Umbraco: " & ex.ToString)
        End Try

        Return lstSearchList
    End Function
    Private Function SearchVideosFor(ByVal searchFor As String) As List(Of DataLayer.SearchList)
        'Instantiate scope variable
        Dim lstSearchList As New List(Of DataLayer.SearchList)

        Try
            'Instantiate variables
            Dim apiCall As String = "https://bdo.workerbeetv.com/wp-content/themes/enterprise/feed/mrssMob.php?apiKey=CF2EC754FCD36&output=xml&limit=1000&sort=ASC&q=" & searchFor
            Dim webClient As WebClient = New WebClient()
            Dim xmlDoc As XmlDocument = New XmlDocument()
            Dim apiResult As String
            Dim lstItems As XmlNodeList

            'Retrieve xml result of search from within videos
            apiResult = webClient.DownloadString(New Uri(apiCall))

            'load xml string into xml document
            xmlDoc.LoadXml(apiResult)

            'extract list of items portion of xml
            lstItems = xmlDoc.DocumentElement.SelectNodes("/rss/channel/item")

            'Loop thru list and extract needed data into a search list.
            For Each item As XmlNode In lstItems
                Dim searchLstItem As New DataLayer.SearchList
                searchLstItem.title = item.SelectSingleNode("title").InnerText
                searchLstItem.url = item.SelectSingleNode("link").InnerText
                searchLstItem.isVideo = True
                'Split path to create a breadcrumb
                Dim segmentId As UInt16 = 0
                For Each segment As String In searchLstItem.url.Split("/").ToList
                    If segmentId > 2 Then
                        searchLstItem.breadcrumb += "&nbsp;&nbsp;⇢&nbsp;&nbsp;"
                    End If
                    If segmentId >= 1 Then
                        searchLstItem.breadcrumb += UppercaseFirstLetter(segment.Replace("-", " ").ToLower)
                    End If
                    segmentId += 1
                Next
                'Add to search list
                lstSearchList.Add(searchLstItem)
            Next

        Catch ex As Exception
            Response.Write("Error retrieving data from WorkerbeeTv: " & ex.ToString)
        End Try

        Return lstSearchList
    End Function
#End Region

End Class